import logging
import math
import os
from typing import Any, Dict, List

import torch
import torchvision.transforms.functional as TF
from PIL import Image

from lightx2v.utils.envs import GET_DTYPE
from lightx2v.utils.set_config import build_startup_config
from lightx2v.utils.utils import find_torch_model_path
from lightx2v_platform.base.global_var import AI_DEVICE

logger = logging.getLogger(__name__)


def read_image_input(image_path):
    img_ori = Image.open(image_path).convert("RGB")
    img = TF.to_tensor(img_ori).sub_(0.5).div_(0.5).unsqueeze(0).to(AI_DEVICE)
    return img, img_ori


def set_config(
    model_path,
    task,
    model_cls,
    config_path=None,
    attn_mode="flash_attn2",
    rope_type="torch_complex_rope",
    infer_steps=50,
    num_frames=81,
    size=(480, 832),
    sample_guide_scale=5.0,
    sample_shift=5.0,
    fps=None,
    aspect_ratio="16:9",
    boundary=0.900,
    boundary_step_index=2,
    denoising_step_list=None,
    double_precision_rope=True,
    modulate_type=None,
    distilled_sigma_values=None,
    cpu_offload=False,
    offload_granularity="block",
    text_encoder_offload=False,
    image_encoder_offload=False,
    vae_offload=False,
    **kwargs,
):
    """
    Load configuration for Wan model.
    """
    if denoising_step_list is None:
        denoising_step_list = [1000, 750, 500, 250]

    # Create arguments object similar to what set_config expects
    args_dict = {
        "task": task,
        "model_path": model_path,
        "model_cls": model_cls,
        "config_json": config_path,
        "cpu_offload": cpu_offload,
        "offload_granularity": offload_granularity,
        "t5_cpu_offload": text_encoder_offload,  # Map to internal keys
        "clip_cpu_offload": image_encoder_offload,  # Map to internal keys
        "vae_cpu_offload": vae_offload,  # Map to internal keys
    }
    if modulate_type is not None:
        args_dict["modulate_type"] = modulate_type
    if fps is not None:
        args_dict["fps"] = fps

    if config_path is None:
        if model_cls == "ltx2":
            args_dict["distilled_sigma_values"] = distilled_sigma_values
            args_dict["infer_steps"] = len(distilled_sigma_values) - 1 if distilled_sigma_values is not None else infer_steps
        else:
            args_dict["infer_steps"] = infer_steps

        args_dict["size"] = list(size)
        args_dict["num_frames"] = num_frames
        args_dict["sample_guide_scale"] = sample_guide_scale
        args_dict["sample_shift"] = sample_shift

        if sample_guide_scale == 1 or (model_cls == "z_image" and sample_guide_scale == 0):
            args_dict["enable_cfg"] = False
        else:
            args_dict["enable_cfg"] = True

        args_dict["rope_type"] = rope_type
        args_dict["aspect_ratio"] = aspect_ratio
        args_dict["boundary"] = boundary
        args_dict["boundary_step_index"] = boundary_step_index
        args_dict["denoising_step_list"] = denoising_step_list
        args_dict["double_precision_rope"] = double_precision_rope

        if model_cls.startswith("wan"):
            # Set all attention types to the provided attn_mode
            args_dict["self_attn_1_type"] = attn_mode
            args_dict["cross_attn_1_type"] = attn_mode
            args_dict["cross_attn_2_type"] = attn_mode
        elif model_cls in ["hunyuan_video_1.5", "qwen_image", "longcat_image", "ltx2", "z_image"]:
            args_dict["attn_type"] = attn_mode

        if model_cls in ["ltx2", "ltx2_5"]:
            args_dict.setdefault("modulate_type", "torch")

    args_dict.update(kwargs)
    return build_startup_config(args_dict)


def load_wan_text_encoder(config: Dict[str, Any]):
    from lightx2v.models.input_encoders.hf.wan.t5.model import T5EncoderModel

    # offload config
    t5_offload = config.get("t5_cpu_offload", config.get("cpu_offload"))
    if t5_offload:
        t5_device = torch.device("cpu")
    else:
        t5_device = torch.device(AI_DEVICE)
    tokenizer_path = os.path.join(config["model_path"], "google/umt5-xxl")
    # quant_config
    t5_quantized = config.get("t5_quantized", False)
    if t5_quantized:
        t5_quant_scheme = config.get("t5_quant_scheme", None)
        assert t5_quant_scheme is not None
        tmp_t5_quant_scheme = t5_quant_scheme.split("-")[0]
        t5_model_name = f"models_t5_umt5-xxl-enc-{tmp_t5_quant_scheme}.pth"
        t5_quantized_ckpt = find_torch_model_path(config, "t5_quantized_ckpt", t5_model_name)
        t5_original_ckpt = None
    else:
        t5_quant_scheme = None
        t5_quantized_ckpt = None
        t5_model_name = "models_t5_umt5-xxl-enc-bf16.pth"
        t5_original_ckpt = find_torch_model_path(config, "t5_original_ckpt", t5_model_name)

    text_encoder = T5EncoderModel(
        text_len=config["text_len"],
        dtype=torch.bfloat16,
        device=t5_device,
        checkpoint_path=t5_original_ckpt,
        tokenizer_path=tokenizer_path,
        shard_fn=None,
        cpu_offload=t5_offload,
        rms_norm_type=config.get("t5_rms_norm_type", "sgl-kernel"),
        t5_quantized=t5_quantized,
        t5_quantized_ckpt=t5_quantized_ckpt,
        quant_scheme=t5_quant_scheme,
        load_from_rank0=config.get("load_from_rank0", False),
        lazy_load=config.get("t5_lazy_load", False),
    )
    # Return single encoder to match original returning list
    text_encoders = [text_encoder]
    return text_encoders


def load_wan_image_encoder(config: Dict[str, Any]):
    from lightx2v.models.input_encoders.hf.wan.xlm_roberta.model import CLIPModel

    image_encoder = None
    if config["task"] in ["i2v", "flf2v", "animate", "s2v"] and config.get("use_image_encoder", True):
        # offload config
        clip_offload = config.get("clip_cpu_offload", config.get("cpu_offload", False))
        if clip_offload:
            clip_device = torch.device("cpu")
        else:
            clip_device = torch.device(AI_DEVICE)
        # quant_config
        clip_quantized = config.get("clip_quantized", False)
        if clip_quantized:
            clip_quant_scheme = config.get("clip_quant_scheme", None)
            assert clip_quant_scheme is not None
            tmp_clip_quant_scheme = clip_quant_scheme.split("-")[0]
            clip_model_name = f"models_clip_open-clip-xlm-roberta-large-vit-huge-14-{tmp_clip_quant_scheme}.pth"
            clip_quantized_ckpt = find_torch_model_path(config, "clip_quantized_ckpt", clip_model_name)
            clip_original_ckpt = None
        else:
            clip_quantized_ckpt = None
            clip_quant_scheme = None
            clip_model_name = "models_clip_open-clip-xlm-roberta-large-vit-huge-14.pth"
            clip_original_ckpt = find_torch_model_path(config, "clip_original_ckpt", clip_model_name)

        image_encoder = CLIPModel(
            dtype=torch.float16,
            device=clip_device,
            checkpoint_path=clip_original_ckpt,
            clip_quantized=clip_quantized,
            clip_quantized_ckpt=clip_quantized_ckpt,
            quant_scheme=clip_quant_scheme,
            cpu_offload=clip_offload,
            use_31_block=config.get("use_31_block", True),
            load_from_rank0=config.get("load_from_rank0", False),
        )

    return image_encoder


def get_vae_parallel(config: Dict[str, Any]):
    if isinstance(config.get("parallel", False), bool):
        return config.get("parallel", False)
    if isinstance(config.get("parallel", False), dict):
        return config.get("parallel", {}).get("vae_parallel", True)
    return False


def load_wan_vae_encoder(config: Dict[str, Any]):
    from lightx2v.models.video_encoders.hf.wan.vae import WanVAE
    from lightx2v.models.video_encoders.hf.wan.vae_2_2 import Wan2_2_VAE

    vae_name = config.get("vae_name", "Wan2.1_VAE.pth")
    if config.get("model_cls", "") == "wan2.2":
        vae_cls = Wan2_2_VAE
    else:
        vae_cls = WanVAE

    # offload config
    vae_offload = config.get("vae_cpu_offload", config.get("cpu_offload"))
    if vae_offload:
        vae_device = torch.device("cpu")
    else:
        vae_device = torch.device(AI_DEVICE)

    vae_config = {
        "vae_path": find_torch_model_path(config, "vae_path", vae_name),
        "device": vae_device,
        "parallel": get_vae_parallel(config),
        "use_tiling": config.get("use_tiling_vae", False),
        "cpu_offload": vae_offload,
        "dtype": GET_DTYPE(),
        "load_from_rank0": config.get("load_from_rank0", False),
        "use_lightvae": config.get("use_lightvae", False),
    }
    if config["task"] not in ["i2v", "flf2v", "animate", "vace", "s2v"]:
        return None
    else:
        return vae_cls(**vae_config)


def load_wan_vae_decoder(config: Dict[str, Any]):
    from lightx2v.models.video_encoders.hf.wan.vae import WanVAE
    from lightx2v.models.video_encoders.hf.wan.vae_2_2 import Wan2_2_VAE
    from lightx2v.models.video_encoders.hf.wan.vae_tiny import Wan2_2_VAE_tiny, WanVAE_tiny

    vae_name = config.get("vae_name", "Wan2.1_VAE.pth")
    tiny_vae_name = "taew2_1.pth"

    if config.get("model_cls", "") == "wan2.2":
        vae_cls = Wan2_2_VAE
        tiny_vae_cls = Wan2_2_VAE_tiny
        tiny_vae_name = "taew2_2.pth"
    else:
        vae_cls = WanVAE
        tiny_vae_cls = WanVAE_tiny
        tiny_vae_name = "taew2_1.pth"

    # offload config
    vae_offload = config.get("vae_cpu_offload", config.get("cpu_offload"))
    if vae_offload:
        vae_device = torch.device("cpu")
    else:
        vae_device = torch.device(AI_DEVICE)

    vae_config = {
        "vae_path": find_torch_model_path(config, "vae_path", vae_name),
        "device": vae_device,
        "parallel": get_vae_parallel(config),
        "use_tiling": config.get("use_tiling_vae", False),
        "cpu_offload": vae_offload,
        "use_lightvae": config.get("use_lightvae", False),
        "dtype": GET_DTYPE(),
        "load_from_rank0": config.get("load_from_rank0", False),
    }
    if config.get("use_tae", False):
        tae_path = find_torch_model_path(config, "tae_path", tiny_vae_name)
        vae_decoder = tiny_vae_cls(vae_path=tae_path, device=AI_DEVICE, need_scaled=config.get("need_scaled", False)).to(AI_DEVICE)
    else:
        vae_decoder = vae_cls(**vae_config)
    return vae_decoder


def load_wan_transformer(config: Dict[str, Any]):
    print(
        "Loading WanModel module: model_cls=%s model_path=%s device=%s dit_quantized=%s lazy_load=%s"
        % (
            config.get("model_cls"),
            config.get("model_path"),
            AI_DEVICE if not config.get("cpu_offload") else "cpu",
            config.get("dit_quantized", False),
            config.get("lazy_load", False),
        ),
        flush=True,
    )
    from lightx2v.models.networks.wan.model import WanModel
    from lightx2v.models.runners.wan.wan_runner import MultiModelStruct, build_wan_model_with_lora, get_wan_model_class
    from lightx2v.models.schedulers.wan.scheduler_factory import get_wan_distill_method

    print(
        "Constructing WanModel: model_cls=%s model_path=%s device=%s dit_quantized=%s lazy_load=%s"
        % (
            config.get("model_cls"),
            config.get("model_path"),
            AI_DEVICE if not config.get("cpu_offload") else "cpu",
            config.get("dit_quantized", False),
            config.get("lazy_load", False),
        ),
        flush=True,
    )

    if config["cpu_offload"]:
        init_device = torch.device("cpu")
    else:
        init_device = torch.device(AI_DEVICE)

    model_class = get_wan_model_class(get_wan_distill_method(config))

    if config.get("model_cls") == "wan2.1":
        wan_model_kwargs = {"model_path": config["model_path"], "config": config, "device": init_device}
        lora_configs = config.get("lora_configs")
        if not lora_configs:
            model = model_class(**wan_model_kwargs)
        else:
            model = build_wan_model_with_lora(WanModel, config, wan_model_kwargs, lora_configs, model_type="wan2.1")
        logger.info("%s construction finished", type(model).__name__)
        return model
    elif config.get("model_cls") == "wan2.2_moe":
        print("Loading MultiModelStruct module start", flush=True)
        print("Loading MultiModelStruct module done", flush=True)

        high_noise_model_path = os.path.join(config["model_path"], "high_noise_model")
        if config.get("dit_quantized", False) and config.get("high_noise_quantized_ckpt", None):
            high_noise_model_path = config["high_noise_quantized_ckpt"]
        elif config.get("high_noise_original_ckpt", None):
            high_noise_model_path = config["high_noise_original_ckpt"]

        low_noise_model_path = os.path.join(config["model_path"], "low_noise_model")
        if config.get("dit_quantized", False) and config.get("low_noise_quantized_ckpt", None):
            low_noise_model_path = config["low_noise_quantized_ckpt"]
        elif not config.get("dit_quantized", False) and config.get("low_noise_original_ckpt", None):
            low_noise_model_path = config["low_noise_original_ckpt"]

        if not config.get("lazy_load", False) and not config.get("unload_modules", False):
            lora_configs = config.get("lora_configs")
            high_model_kwargs = {
                "model_path": high_noise_model_path,
                "config": config,
                "device": init_device,
                "model_type": "wan2.2_moe_high_noise",
            }
            low_model_kwargs = {
                "model_path": low_noise_model_path,
                "config": config,
                "device": init_device,
                "model_type": "wan2.2_moe_low_noise",
            }
            if not lora_configs:
                high_noise_model = model_class(**high_model_kwargs)
                low_noise_model = model_class(**low_model_kwargs)
            else:
                high_noise_model = build_wan_model_with_lora(WanModel, config, high_model_kwargs, lora_configs, model_type="high_noise_model")
                low_noise_model = build_wan_model_with_lora(WanModel, config, low_model_kwargs, lora_configs, model_type="low_noise_model")

            logger.info("%s construction finished for wan2.2_moe", type(high_noise_model).__name__)
            return MultiModelStruct([high_noise_model, low_noise_model], config)
        else:
            model_struct = MultiModelStruct([None, None], config)
            model_struct.low_noise_model_path = low_noise_model_path
            model_struct.high_noise_model_path = high_noise_model_path
            model_struct.init_device = init_device
            return model_struct
    else:
        logger.error(f"Unsupported model_cls: {config.get('model_cls')}")
        raise ValueError(f"Unsupported model_cls: {config.get('model_cls')}")


def estimate_encoder_buffer_sizes(config: Dict[str, Any]) -> List[int]:
    text_len = int(config.get("text_len", 512))
    enable_cfg = bool(config.get("enable_cfg", False))
    use_image_encoder = bool(config.get("use_image_encoder", True))
    task = config.get("task", "i2v")

    text_dim = int(config.get("text_encoder_dim", 4096))
    clip_dim = int(config.get("clip_embed_dim", 1024))
    z_dim = int(config.get("vae_z_dim", 16))

    vae_stride = config.get("vae_stride", (4, 8, 8))
    stride_t = int(vae_stride[0])
    stride_h = int(vae_stride[1])
    stride_w = int(vae_stride[2])

    num_frames = int(config.get("num_frames", 81))
    target_height, target_width = map(int, config.get("size", (480, 832)))

    t_prime = 1 + (num_frames - 1) // stride_t
    h_prime = int(math.ceil(target_height / stride_h))
    w_prime = int(math.ceil(target_width / stride_w))

    bytes_per_elem = torch.tensor([], dtype=torch.float32).element_size()
    int_bytes_per_elem = torch.tensor([], dtype=torch.int64).element_size()

    buffer_sizes = []
    context_bytes = text_len * text_dim * bytes_per_elem
    buffer_sizes.append(context_bytes)
    if enable_cfg:
        buffer_sizes.append(context_bytes)

    if task == "i2v":
        if use_image_encoder:
            buffer_sizes.append(clip_dim * bytes_per_elem)
        vae_bytes = (z_dim + 4) * t_prime * h_prime * w_prime * bytes_per_elem
        buffer_sizes.append(vae_bytes)

    latent_shape_bytes = 4 * int_bytes_per_elem
    buffer_sizes.append(latent_shape_bytes)

    # Metadata buffer for integrity checks (hashes + shapes)
    buffer_sizes.append(4096)

    return buffer_sizes


def estimate_transformer_buffer_sizes(config: Dict[str, Any]) -> List[int]:
    z_dim = int(config.get("vae_z_dim", 16))

    vae_stride = config.get("vae_stride", (4, 8, 8))
    stride_t = int(vae_stride[0])
    stride_h = int(vae_stride[1])
    stride_w = int(vae_stride[2])

    num_frames = int(config.get("num_frames", 81))
    target_height, target_width = map(int, config.get("size", (480, 832)))

    t_prime = 1 + (num_frames - 1) // stride_t
    h_prime = int(math.ceil(target_height / stride_h))
    w_prime = int(math.ceil(target_width / stride_w))

    bytes_per_elem = torch.tensor([], dtype=torch.float32).element_size()
    latents_bytes = z_dim * t_prime * h_prime * w_prime * bytes_per_elem
    return [int(latents_bytes), 4096]
