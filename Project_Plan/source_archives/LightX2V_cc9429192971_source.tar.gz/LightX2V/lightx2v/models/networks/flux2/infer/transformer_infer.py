import torch
import torch.distributed as dist
import torch.nn.functional as F

from lightx2v.common.transformer_infer.transformer_infer import BaseTransformerInfer


class Flux2TransformerInfer(BaseTransformerInfer):
    def __init__(self, config):
        self.config = config
        self.infer_conditional = True
        self.clean_cuda_cache = self.config.get("clean_cuda_cache", False)

        self.tp_group = None
        self.tp_rank = 0
        self.tp_size = 1
        if self.config.get("tensor_parallel", False):
            self.tp_group = self.config.get("device_mesh").get_group(mesh_dim="tensor_p")
            self.tp_rank = dist.get_rank(self.tp_group)
            self.tp_size = dist.get_world_size(self.tp_group)

        self.inner_dim = config.get("num_attention_heads", 24) * config.get("attention_head_dim", 64)

        if self.config.get("seq_parallel", False):
            self.seq_p_group = self.config.get("device_mesh").get_group(mesh_dim="seq_p")
            parallel_config = self.config["parallel"]
            self.seq_p_prepost_backend = parallel_config.get("seq_p_prepost_backend", "torch")
            self.seq_p_a2a_backend = parallel_config.get("seq_p_a2a_backend", "torch")
            self.seq_p_quant_scheme = parallel_config.get("seq_p_quant_scheme")
            if self.seq_p_quant_scheme is not None and self.seq_p_quant_scheme not in ("fp8", "fp4"):
                raise ValueError(f"Unknown seq_p_quant_scheme={self.seq_p_quant_scheme!r}; expected None, 'fp8', or 'fp4'.")
            self.seq_p_tensor_fusion = parallel_config.get("seq_p_tensor_fusion", False)
            self.enable_head_parallel = parallel_config.get("seq_p_head_parallel", False)
        else:
            self.seq_p_group = None
            self.seq_p_prepost_backend = "torch"
            self.seq_p_a2a_backend = "torch"
            self.seq_p_quant_scheme = None
            self.seq_p_tensor_fusion = False
            self.enable_head_parallel = False

    def _maybe_apply_stale_kv(self, key, value, num_txt_tokens, block_idx, block_type=None):
        """Hook for stale-KV cache in PipeFusion mode.  No-op in base class.

        Subclasses (PipeFusion) override this to cache image KV across patches
        while keeping text KV fresh. ``block_type`` distinguishes double vs
        single blocks, whose ``block_idx`` both restart from 0.
        """
        return key, value

    def set_scheduler(self, scheduler):
        self.scheduler = scheduler

    def _split_double_modulation(self, mod):
        if mod.ndim == 2:
            mod = mod.unsqueeze(1)
        mod_params = torch.chunk(mod, 6, dim=-1)
        return mod_params[0:3], mod_params[3:6]

    def _split_single_modulation(self, mod):
        if mod.ndim == 2:
            mod = mod.unsqueeze(1)
        mod_params = torch.chunk(mod, 3, dim=-1)
        return mod_params

    def infer_double_stream_block(
        self,
        block_weights,
        hidden_states,
        encoder_hidden_states,
        temb_mod_img,
        temb_mod_txt,
        image_rotary_emb,
        image_rotary_positions,
        img_attn_hook=None,
    ):
        heads = self.config["num_attention_heads"] // self.tp_size
        head_dim = self.config["attention_head_dim"]

        (shift_msa, scale_msa, gate_msa), (shift_mlp, scale_mlp, gate_mlp) = self._split_double_modulation(temb_mod_img)
        (c_shift_msa, c_scale_msa, c_gate_msa), (c_shift_mlp, c_scale_mlp, c_gate_mlp) = self._split_double_modulation(temb_mod_txt)
        norm_hidden_states = block_weights.norm1.apply(hidden_states)
        norm_hidden_states = (norm_hidden_states * (1 + scale_msa) + shift_msa).squeeze(0)

        norm_encoder_hidden_states = block_weights.norm1_context.apply(encoder_hidden_states)
        norm_encoder_hidden_states = (norm_encoder_hidden_states * (1 + c_scale_msa) + c_shift_msa).squeeze(0)

        img_query = block_weights.to_q.apply(norm_hidden_states)
        img_key = block_weights.to_k.apply(norm_hidden_states)
        img_value = block_weights.to_v.apply(norm_hidden_states)

        txt_query = block_weights.add_q_proj.apply(norm_encoder_hidden_states)
        txt_key = block_weights.add_k_proj.apply(norm_encoder_hidden_states)
        txt_value = block_weights.add_v_proj.apply(norm_encoder_hidden_states)

        img_query = img_query.unflatten(-1, (heads, head_dim))
        img_key = img_key.unflatten(-1, (heads, head_dim))
        img_value = img_value.unflatten(-1, (heads, head_dim))
        txt_query = txt_query.unflatten(-1, (heads, head_dim))
        txt_key = txt_key.unflatten(-1, (heads, head_dim))
        txt_value = txt_value.unflatten(-1, (heads, head_dim))

        img_query = block_weights.norm_q.apply(img_query)
        img_key = block_weights.norm_k.apply(img_key)
        txt_query = block_weights.norm_added_q.apply(txt_query)
        txt_key = block_weights.norm_added_k.apply(txt_key)

        query = torch.cat([txt_query, img_query], dim=0)
        key = torch.cat([txt_key, img_key], dim=0)

        query, key = block_weights.rope.apply(query, key, image_rotary_emb, positions=image_rotary_positions)

        model_cls = self.config.get("model_cls", "flux2_klein")

        if self.seq_p_group is not None:
            txt_len = txt_query.shape[0]
            img_attn_output, txt_attn_output = block_weights.calculate_parallel.apply(
                q=query[txt_len:],
                k=key[txt_len:],
                v=img_value,
                aux_q=query[:txt_len],
                aux_k=key[:txt_len],
                aux_v=txt_value,
                attention_module=block_weights.calculate,
                seq_p_group=self.seq_p_group,
                prepost_backend=self.seq_p_prepost_backend,
                a2a_backend=self.seq_p_a2a_backend,
                quant_scheme=self.seq_p_quant_scheme,
                tensor_fusion=self.seq_p_tensor_fusion,
                head_parallel=self.enable_head_parallel,
                aux_first=True,
                attention_kwargs={"model_cls": model_cls},
            )
            if txt_attn_output is None:
                raise RuntimeError("Flux2 double-stream attention expected a text auxiliary output.")
        else:
            value = torch.cat([txt_value, img_value], dim=0)
            num_txt_tokens = encoder_hidden_states.shape[0]
            key, value = self._maybe_apply_stale_kv(key, value, num_txt_tokens, block_weights.block_idx, block_type=block_weights.block_type)
            total_len = query.shape[0]
            kv_len = key.shape[0]  # may differ from total_len in PipeFusion (stale-KV)
            cu_seqlens_q = torch.tensor([0, total_len], dtype=torch.int32)
            cu_seqlens_kv = torch.tensor([0, kv_len], dtype=torch.int32)
            attn_output = block_weights.calculate.apply(
                q=query,
                k=key,
                v=value,
                cu_seqlens_q=cu_seqlens_q,
                cu_seqlens_kv=cu_seqlens_kv,
                max_seqlen_q=total_len,
                max_seqlen_kv=kv_len,
                model_cls=model_cls,
            )
            txt_len = encoder_hidden_states.shape[0]
            txt_attn_output = attn_output[:txt_len]
            img_attn_output = attn_output[txt_len:]

        img_attn_output = block_weights.to_out.apply(img_attn_output)
        txt_attn_output = block_weights.to_add_out.apply(txt_attn_output)

        gated_img_attn = gate_msa * img_attn_output
        if img_attn_hook is not None:
            img_attn_hook(gated_img_attn)
        hidden_states = hidden_states + gated_img_attn
        encoder_hidden_states = encoder_hidden_states + c_gate_msa * txt_attn_output
        norm_hidden_states2 = block_weights.norm2.apply(hidden_states)
        norm_hidden_states2 = (norm_hidden_states2 * (1 + scale_mlp) + shift_mlp).squeeze(0)
        ff_output = block_weights.ff_net_0.apply(norm_hidden_states2)
        ff_1, ff_2 = ff_output.chunk(2, dim=-1)
        ff_output = F.silu(ff_1) * ff_2
        ff_output = block_weights.ff_net_2.apply(ff_output)
        hidden_states = hidden_states + gate_mlp * ff_output

        norm_encoder_hidden_states2 = block_weights.norm2_context.apply(encoder_hidden_states)
        norm_encoder_hidden_states2 = (norm_encoder_hidden_states2 * (1 + c_scale_mlp) + c_shift_mlp).squeeze(0)
        context_ff_output = block_weights.ff_context_net_0.apply(norm_encoder_hidden_states2)
        ctx_ff_1, ctx_ff_2 = context_ff_output.chunk(2, dim=-1)
        context_ff_output = F.silu(ctx_ff_1) * ctx_ff_2
        context_ff_output = block_weights.ff_context_net_2.apply(context_ff_output)
        encoder_hidden_states = encoder_hidden_states + c_gate_mlp * context_ff_output
        if encoder_hidden_states.dtype == torch.float16:
            encoder_hidden_states = encoder_hidden_states.clip(-65504, 65504)

        return encoder_hidden_states.squeeze(0), hidden_states.squeeze(0)

    def infer_single_stream_block(
        self,
        block_weights,
        hidden_states,
        encoder_hidden_states,
        temb_mod,
        image_rotary_emb,
        image_rotary_positions,
        num_txt_tokens=0,
    ):
        heads = self.config["num_attention_heads"] // self.tp_size
        head_dim = self.config["attention_head_dim"]

        if encoder_hidden_states is not None:
            raise ValueError("Encoder hidden states already cat in hidden states for single-stream blocks in Flux2, should be None here")

        residual = hidden_states

        shift_msa, scale_msa, gate_msa = self._split_single_modulation(temb_mod)

        norm_combined = block_weights.norm.apply(hidden_states)
        norm_combined = (norm_combined * (1 + scale_msa) + shift_msa).squeeze(0)

        hidden_states_proj = block_weights.to_qkv_mlp_proj.apply(norm_combined)
        inner_dim = heads * head_dim
        qkv, mlp_hidden_states = torch.split(hidden_states_proj, [3 * inner_dim, hidden_states_proj.shape[-1] - 3 * inner_dim], dim=-1)
        query, key, value = qkv.chunk(3, dim=-1)

        query = query.unflatten(-1, (heads, head_dim))
        key = key.unflatten(-1, (heads, head_dim))
        value = value.unflatten(-1, (heads, head_dim))

        query = block_weights.norm_q.apply(query)
        key = block_weights.norm_k.apply(key)

        query, key = block_weights.rope.apply(query, key, image_rotary_emb, positions=image_rotary_positions)

        model_cls = self.config.get("model_cls", "flux2_klein")

        if self.seq_p_group is not None:
            img_attn_output, txt_attn_output = block_weights.calculate_parallel.apply(
                q=query[num_txt_tokens:],
                k=key[num_txt_tokens:],
                v=value[num_txt_tokens:],
                aux_q=query[:num_txt_tokens],
                aux_k=key[:num_txt_tokens],
                aux_v=value[:num_txt_tokens],
                attention_module=block_weights.calculate,
                seq_p_group=self.seq_p_group,
                prepost_backend=self.seq_p_prepost_backend,
                a2a_backend=self.seq_p_a2a_backend,
                quant_scheme=self.seq_p_quant_scheme,
                tensor_fusion=self.seq_p_tensor_fusion,
                head_parallel=self.enable_head_parallel,
                aux_first=True,
                attention_kwargs={"model_cls": model_cls},
            )
            if txt_attn_output is None:
                raise RuntimeError("Flux2 single-stream attention expected a text auxiliary output.")
            attn_output = torch.cat([txt_attn_output, img_attn_output], dim=0)
        else:
            key, value = self._maybe_apply_stale_kv(key, value, num_txt_tokens, block_weights.block_idx, block_type=block_weights.block_type)
            total_len = query.shape[0]
            kv_len = key.shape[0]  # may differ from total_len in PipeFusion (stale-KV)
            cu_seqlens_q = torch.tensor([0, total_len], dtype=torch.int32)
            cu_seqlens_kv = torch.tensor([0, kv_len], dtype=torch.int32)
            attn_output = block_weights.calculate.apply(
                q=query,
                k=key,
                v=value,
                cu_seqlens_q=cu_seqlens_q,
                cu_seqlens_kv=cu_seqlens_kv,
                max_seqlen_q=total_len,
                max_seqlen_kv=kv_len,
                model_cls=model_cls,
            )

        mlp_1, mlp_2 = mlp_hidden_states.chunk(2, dim=-1)
        mlp_hidden_states = F.silu(mlp_1) * mlp_2

        combined_output = torch.cat([attn_output, mlp_hidden_states], dim=-1)
        combined_output = block_weights.to_out.apply(combined_output)

        hidden_states = residual + gate_msa * combined_output
        hidden_states = hidden_states.squeeze(0)
        if hidden_states.dtype == torch.float16:
            hidden_states = hidden_states.clip(-65504, 65504)

        return hidden_states

    def _infer_forward(self, block_weights, pre_infer_out, decisive_block_id=None, on_decisive_block=None):
        hidden_states = pre_infer_out.hidden_states
        encoder_hidden_states = pre_infer_out.encoder_hidden_states
        timestep = pre_infer_out.timestep
        image_rotary_emb = pre_infer_out.image_rotary_emb
        image_rotary_positions = pre_infer_out.image_rotary_positions

        num_txt_tokens = encoder_hidden_states.shape[0]
        timestep_act = F.silu(timestep)
        double_stream_mod_img = block_weights.double_stream_modulation_img_linear.apply(timestep_act)
        double_stream_mod_txt = block_weights.double_stream_modulation_txt_linear.apply(timestep_act)
        single_stream_mod = block_weights.single_stream_modulation_linear.apply(timestep_act)

        for block_idx, block in enumerate(block_weights.double_blocks):
            block_hook = on_decisive_block if block_idx == decisive_block_id else None
            encoder_hidden_states, hidden_states = self.infer_double_stream_block(
                block,
                hidden_states,
                encoder_hidden_states,
                double_stream_mod_img,
                double_stream_mod_txt,
                image_rotary_emb,
                image_rotary_positions,
                img_attn_hook=block_hook,
            )

        hidden_states = torch.cat([encoder_hidden_states, hidden_states], dim=0)

        for block in block_weights.single_blocks:
            hidden_states = self.infer_single_stream_block(
                block,
                hidden_states,
                None,
                single_stream_mod,
                image_rotary_emb,
                image_rotary_positions,
                num_txt_tokens=num_txt_tokens,
            )
        return hidden_states[num_txt_tokens:, ...]

    def infer(self, block_weights, pre_infer_out):
        return self._infer_forward(block_weights, pre_infer_out)


# Backward-compatible alias
Flux2KleinTransformerInfer = Flux2TransformerInfer
