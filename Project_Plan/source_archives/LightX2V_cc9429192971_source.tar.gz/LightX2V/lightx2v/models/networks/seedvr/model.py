import os

import torch
import torch.distributed as dist

from lightx2v.models.networks.base_model import BaseTransformerModel
from lightx2v.models.networks.seedvr.infer.offload.transformer_infer import SeedVROffloadTransformerInfer
from lightx2v.models.networks.seedvr.infer.post_infer import SeedVRPostInfer
from lightx2v.models.networks.seedvr.infer.pre_infer import SeedVRPreInfer
from lightx2v.models.networks.seedvr.infer.transformer_infer import SeedVRTransformerInfer
from lightx2v.models.networks.seedvr.utils import na as na_utils
from lightx2v.models.networks.seedvr.weights.post_weights import SeedVRPostWeights
from lightx2v.models.networks.seedvr.weights.pre_weights import SeedVRPreWeights
from lightx2v.models.networks.seedvr.weights.transformer_weights import SeedVRTransformerWeights
from lightx2v.utils.envs import GET_DTYPE, GET_SENSITIVE_DTYPE
from lightx2v_platform.base.global_var import AI_DEVICE


class SeedVRNaDiTModel(BaseTransformerModel):
    """SeedVR model using LightX2V weight wrappers + inference pipeline."""

    pre_weight_class = SeedVRPreWeights
    transformer_weight_class = SeedVRTransformerWeights
    post_weight_class = SeedVRPostWeights

    def __init__(self, model_path, config, device, model_type="seedvr", lora_path=None, lora_strength=1.0):
        super().__init__(model_path, config, device, model_type, lora_path, lora_strength)
        self._apply_seedvr_defaults()
        self._init_infer_class()
        self._init_weights()
        self._init_infer()

    def _apply_seedvr_defaults(self):
        common_defaults = {
            "vid_in_channels": 33,
            "vid_out_channels": 16,
            "txt_in_dim": 5120,
            "head_dim": 128,
            "expand_ratio": 4,
            "norm": "fusedrms",
            "norm_eps": 1.0e-5,
            "ada": "single",
            "qk_bias": False,
            "qk_norm": "fusedrms",
            "patch_size": (1, 2, 2),
            "rms_norm_type": "torch",
            "layer_norm_type": "torch",
            "timestep_sinusoidal_dim": 256,
            "seq_parallel": False,
            "seedvr_has_vid_in": True,
        }
        for key, value in common_defaults.items():
            self.config.setdefault(key, value)

        if self.config.get("model_size") == "7b":
            defaults = {
                "vid_dim": 3072,
                "txt_dim": 3072,
                "heads": 24,
                "num_layers": 36,
                "block_type": ["mmdit_sr"] * 36,
                "mlp_type": "normal",
                "qk_rope": True,
                "rope_type": "rope3d",
                "rope_dim": 64,
                "window": [(4, 3, 3)] * 36,
                "window_method": ["720pwin_by_size_bysize", "720pswin_by_size_bysize"] * 18,
                "last_layer_vid_only": False,
            }
        else:
            defaults = {
                "vid_dim": 2560,
                "txt_dim": 2560,
                "heads": 20,
                "num_layers": 32,
                "block_type": ["mmdit_sr"] * 32,
                "mm_layers": 10,
                "mlp_type": "swiglu",
                "rope_type": "mmrope3d",
                "rope_dim": 128,
                "window": [(4, 3, 3)] * 32,
                "window_method": ["720pwin_by_size_bysize", "720pswin_by_size_bysize"] * 16,
                "vid_out_norm": "fusedrms",
                "last_layer_vid_only": True,
            }
        for key, value in defaults.items():
            self.config.setdefault(key, value)

        self.config.setdefault("emb_dim", 6 * self.config["vid_dim"])

        self.config.setdefault("dit_quant_scheme", "Default")
        self.config.setdefault("dit_quantized", False)

    def _init_infer_class(self):
        self.pre_infer_class = SeedVRPreInfer
        if self.cpu_offload and self.offload_granularity == "block":
            self.transformer_infer_class = SeedVROffloadTransformerInfer
        elif not self.cpu_offload or self.offload_granularity == "model":
            self.transformer_infer_class = SeedVRTransformerInfer
        else:
            raise ValueError(f"Unsupported SeedVR offload_granularity: {self.offload_granularity}")
        self.post_infer_class = SeedVRPostInfer

    def _init_infer(self):
        self.pre_infer = self.pre_infer_class(self.config)
        self.transformer_infer = self.transformer_infer_class(self.config)
        self.post_infer = self.post_infer_class(self.config)
        if hasattr(self.transformer_infer, "offload_manager"):
            self._init_offload_manager()

    def _load_ckpt(self, unified_dtype, sensitive_layer):
        # SeedVR weights are typically in .pth/.pt format, not safetensors.
        ckpt_path = self.config.get("dit_original_ckpt") or self.model_path
        if ckpt_path and os.path.isfile(ckpt_path):
            ckpt_lower = str(ckpt_path).lower()
            if not ckpt_lower.endswith(".safetensors"):
                try:
                    distributed_rank0_load = dist.is_initialized() and self.config.get("load_from_rank0", False)
                    map_location = "cpu" if self.device.type == "cpu" or distributed_rank0_load else AI_DEVICE
                    load_kwargs = {"map_location": map_location}
                    if map_location == "cpu":
                        load_kwargs.update({"mmap": True, "weights_only": True})
                    try:
                        state = torch.load(ckpt_path, **load_kwargs)
                    except Exception:
                        # Older torch versions and checkpoints with custom globals may
                        # not support the low-peak weights-only mmap path.
                        load_kwargs.pop("weights_only", None)
                        try:
                            state = torch.load(ckpt_path, **load_kwargs)
                        except TypeError:
                            load_kwargs.pop("mmap", None)
                            state = torch.load(ckpt_path, **load_kwargs)
                    if isinstance(state, dict) and "state_dict" in state:
                        state = state["state_dict"]
                    remove_keys = self.remove_keys if hasattr(self, "remove_keys") else []
                    weight_dict = {}
                    for key, tensor in state.items():
                        if "attn.rope.rope.freqs" in key or any(remove_key in key for remove_key in remove_keys):
                            continue
                        if unified_dtype or all(s not in key for s in sensitive_layer):
                            weight_dict[key] = tensor.to(GET_DTYPE())
                        else:
                            weight_dict[key] = tensor.to(GET_SENSITIVE_DTYPE())
                    return weight_dict
                except Exception:
                    # Fall back to BaseTransformerModel loader
                    pass

        # Fallback to BaseTransformerModel safetensors loader
        return super()._load_ckpt(unified_dtype, sensitive_layer)

    @torch.no_grad()
    def _seq_parallel_pre_process(self, pre_infer_out):
        return pre_infer_out

    @torch.no_grad()
    def _seq_parallel_post_process(self, x):
        return x

    @torch.no_grad()
    def _infer_cond_uncond(self, inputs, infer_condition=True):
        pass

    @torch.no_grad()
    def _infer_dit(self, vid, txt, vid_shape, txt_shape, timestep):
        pre_infer_out = self.pre_infer.infer(
            weights=self.pre_weight,
            vid=vid,
            txt=txt,
            vid_shape=vid_shape,
            txt_shape=txt_shape,
            timestep=timestep,
        )

        if self.config.get("seq_parallel", False):
            pre_infer_out = self._seq_parallel_pre_process(pre_infer_out)

        vid, txt, vid_shape, txt_shape = self.transformer_infer.infer(
            self.transformer_weights.blocks,
            pre_infer_out,
        )

        vid = self.post_infer.infer(self.post_weight, vid, pre_infer_out)

        if self.config.get("seq_parallel", False):
            vid = self._seq_parallel_post_process(vid)

        return vid

    @torch.no_grad()
    def infer(self, inputs):
        noises = inputs.get("noises", None)
        conditions = inputs.get("conditions", None)
        texts_pos = inputs["text_encoder_output"]["texts_pos"]

        if self.cpu_offload and self.offload_granularity == "block":
            # Each request/segment must begin with block 0 even if a previous
            # inference was interrupted before the final buffer swap.
            self.transformer_infer.offload_manager.need_init_first_buffer = True

        if self.cpu_offload:
            if self.offload_granularity == "model":
                self.to_cuda()
            else:
                self.pre_weight.to_cuda()
                self.post_weight.to_cuda()
            texts_pos[0] = texts_pos[0].to(AI_DEVICE)

        text_pos_embeds, text_pos_shapes = na_utils.flatten(texts_pos)
        latents, latents_shapes = na_utils.flatten(noises)
        latents_cond, _ = na_utils.flatten(conditions)
        batch_size = len(noises)

        latents = self.scheduler.sampler.sample(
            x=latents,
            f=lambda args: self._infer_dit(
                vid=torch.cat([args.x_t, latents_cond], dim=-1),
                txt=text_pos_embeds,
                vid_shape=latents_shapes,
                txt_shape=text_pos_shapes,
                timestep=args.t.repeat(batch_size),
            ),
        )

        latents_list = na_utils.unflatten(latents, latents_shapes)
        self.scheduler.latents = latents_list
        if self.cpu_offload:
            if self.offload_granularity == "model":
                self.to_cpu()
            else:
                self.pre_weight.to_cpu()
                self.post_weight.to_cpu()
        return
