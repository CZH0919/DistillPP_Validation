import math
from typing import Optional

import torch
import torch.distributed as dist
import torch.nn.functional as F
from loguru import logger

from lightx2v.models.networks.base_model import BaseTransformerModel
from lightx2v.models.networks.ltx2.infer.ar_transformer_infer import LTX2ARTransformerInfer
from lightx2v.models.networks.ltx2.infer.offload.transformer_infer import (
    LTX2OffloadTransformerInfer,
)
from lightx2v.models.networks.ltx2.infer.post_infer import LTX2PostInfer
from lightx2v.models.networks.ltx2.infer.pre_infer import LTX2PreInfer
from lightx2v.models.networks.ltx2.infer.transformer_infer import (
    LTX2TransformerInfer,
)
from lightx2v.models.networks.ltx2.weights.post_weights import LTX2PostWeights
from lightx2v.models.networks.ltx2.weights.pre_weights import LTX2PreWeights
from lightx2v.models.networks.ltx2.weights.transformer_weights import (
    LTX2TransformerWeights,
)
from lightx2v.utils.envs import *
from lightx2v.utils.utils import *
from lightx2v_platform.base.global_var import AI_DEVICE

torch_device_module = getattr(torch, AI_DEVICE)


def _multimodal_guider_calculate(
    cond: torch.Tensor,
    uncond_text: Optional[torch.Tensor],
    uncond_perturbed: Optional[torch.Tensor],
    uncond_modality: Optional[torch.Tensor],
    *,
    cfg_scale: float,
    stg_scale: float,
    modality_scale: float,
    rescale_scale: float,
) -> torch.Tensor:
    """与 ltx_core MultiModalGuider.calculate 一致（避免从 scheduler 大模块导入导致循环依赖/旧缓存问题）。"""
    if not math.isclose(cfg_scale, 1.0) and uncond_text is None:
        raise ValueError("mm_guider: cfg_scale != 1 时需要 uncond 前向，但 uncond_text 为 None")

    dtype = cond.dtype
    cond = cond.float()
    ut = uncond_text.float() if not math.isclose(cfg_scale, 1.0) else cond
    up = uncond_perturbed.float() if not math.isclose(stg_scale, 0.0) else cond
    um = uncond_modality.float() if not math.isclose(modality_scale, 1.0) else cond

    pred = cond + (cfg_scale - 1.0) * (cond - ut) + stg_scale * (cond - up) + (modality_scale - 1.0) * (cond - um)

    if not math.isclose(rescale_scale, 0.0):
        factor = cond.std() / pred.std()
        factor = rescale_scale * factor + (1.0 - rescale_scale)
        pred = pred * factor

    return pred.to(dtype)


def _mm_guider_should_skip_step(skip_step: int, step_index: int) -> bool:
    """与 ltx_core MultiModalGuider.should_skip_step 一致。"""
    if skip_step == 0:
        return False
    return step_index % (skip_step + 1) != 0


class LTX2Model(BaseTransformerModel):
    pre_weight_class = LTX2PreWeights
    transformer_weight_class = LTX2TransformerWeights
    post_weight_class = LTX2PostWeights
    pre_infer_class = LTX2PreInfer
    post_infer_class = LTX2PostInfer
    transformer_infer_class = LTX2TransformerInfer
    offload_transformer_infer_class = LTX2OffloadTransformerInfer

    def __init__(self, model_path, config, device, lora_path=None, lora_strength=1.0):
        super().__init__(model_path, config, device, None, lora_path, lora_strength)

        # Track original video sequence length before padding (for sequence parallel)
        self.original_video_seq_len = None

        # self.model_type = model_type
        self.remove_keys = ["text_embedding_projection", "audio_vae", "vae", "vocoder", "model.diffusion_model.audio_embeddings_connector", "model.diffusion_model.video_embeddings_connector"]
        if self.lazy_load:
            self.remove_keys.extend(["diffusion_model.transformer_blocks."])
        self._init_infer_class()
        self._init_weights()
        self._init_infer()

    def _init_infer_class(self):
        if self.cpu_offload:
            self.transformer_infer_class = self.offload_transformer_infer_class

    def _should_load_weights(self):
        """Determine if current rank should load weights from disk."""
        if self.config.get("device_mesh") is None:
            # Single GPU mode
            return True
        elif dist.is_initialized():
            if self.use_tp:
                # Multi-GPU mode, only rank 0 loads
                if dist.get_rank() == 0:
                    logger.info(f"Loading weights from {self.model_path}")
                    return True
            else:
                return True
        return False

    def _remap_lora_dict_keys_for_mm_weight(self, weight_dict):
        if not weight_dict:
            return weight_dict
        prefix = "model.diffusion_model.blocks.diffusion_model."
        out = {}
        for k, v in weight_dict.items():
            if k.startswith("model.diffusion_model.blocks.diffusion_model."):
                out[k] = v
            elif k.startswith("transformer_blocks."):
                out[prefix + k] = v
            else:
                out[k] = v
        return out

    def _load_lora_file(self, file_path):
        d = super()._load_lora_file(file_path)
        return self._remap_lora_dict_keys_for_mm_weight(d)

    def _update_lora(self, lora_path, strength):
        if isinstance(lora_path, dict):
            lora_weight = self._remap_lora_dict_keys_for_mm_weight(lora_path)
        else:
            lora_weight = self._load_lora_file(lora_path)
        self.pre_weight.update_lora(lora_weight, strength)
        self.transformer_weights.update_lora(lora_weight, strength)
        self.post_weight.update_lora(lora_weight, strength)

    def _load_weights_from_rank0(self, weight_dict, is_weight_loader):
        """
        Load and distribute weights from rank 0 to all ranks.

        Supports tensor parallel mode on the configured accelerator platform.
        CPU offload is not supported.
        """
        # CPU offload is not supported
        if self.cpu_offload:
            raise NotImplementedError("_load_weights_from_rank0 does not support CPU offload. Please set cpu_offload=False.")

        logger.info(f"Loading distributed weights with tensor parallel on {AI_DEVICE}")
        global_src_rank = 0

        if is_weight_loader:
            # Rank 0: prepare weights (split for TP)
            processed_weight_dict = {}
            meta_dict = {}

            for key, tensor in weight_dict.items():
                # Only process .weight keys for TP splitting (bias is handled separately)
                if key.endswith(".weight") and self._is_tp_weight(key):
                    # Split weights for TP: create one entry per rank with original key name
                    split_weights = self._split_weight_for_tp(key, tensor, self.tp_size)
                    # Store all split weights temporarily (will be filtered by rank later)
                    for rank_idx in range(self.tp_size):
                        rank_key = f"{key}__tp_rank_{rank_idx}"
                        processed_weight_dict[rank_key] = split_weights[rank_idx]
                        if rank_idx == 0:  # Use rank 0's shape for meta (all ranks have same shape after split)
                            meta_dict[key] = {"shape": split_weights[rank_idx].shape, "dtype": split_weights[rank_idx].dtype, "is_tp": True}

                    # Also handle bias if it exists (for column split weights)
                    bias_key = key.replace(".weight", ".bias")
                    if bias_key in weight_dict and self._get_split_type(key) == "col":
                        # Column split: bias also needs to be split
                        bias_tensor = weight_dict[bias_key]
                        assert bias_tensor.shape[0] % self.tp_size == 0, f"bias dimension ({bias_tensor.shape[0]}) must be divisible by tp_size ({self.tp_size}) for {bias_key}"
                        chunk_size = bias_tensor.shape[0] // self.tp_size
                        for rank_idx in range(self.tp_size):
                            rank_bias_key = f"{bias_key}__tp_rank_{rank_idx}"
                            start_idx = rank_idx * chunk_size
                            end_idx = start_idx + chunk_size
                            processed_weight_dict[rank_bias_key] = bias_tensor[start_idx:end_idx]
                            if rank_idx == 0:
                                meta_dict[bias_key] = {"shape": bias_tensor[start_idx:end_idx].shape, "dtype": bias_tensor.dtype, "is_tp": True}
                        # For row split weights, bias is not split (added after all-reduce)
                else:
                    # Non-TP weights or bias (bias is handled above if it's a TP weight's bias)
                    # Skip bias keys that are already processed above
                    if not (key.endswith(".bias") and key.replace(".bias", ".weight") in processed_weight_dict):
                        processed_weight_dict[key] = tensor
                        meta_dict[key] = {"shape": tensor.shape, "dtype": tensor.dtype, "is_tp": False}

            obj_list = [meta_dict]
            dist.broadcast_object_list(obj_list, src=global_src_rank)
            synced_meta_dict = obj_list[0]
            weight_dict = processed_weight_dict  # Use processed weights
        else:
            obj_list = [None]
            dist.broadcast_object_list(obj_list, src=global_src_rank)
            synced_meta_dict = obj_list[0]

        # Allocate tensors on the accelerator selected by the platform layer.
        distributed_weight_dict = {}
        device = torch.device(f"{AI_DEVICE}:{torch_device_module.current_device()}")
        for key, meta in synced_meta_dict.items():
            is_tp = meta.get("is_tp", False)
            if is_tp:
                # TP weight: each rank gets its own slice
                distributed_weight_dict[key] = torch.empty(meta["shape"], dtype=meta["dtype"], device=device)
            else:
                # Non-TP weight: all ranks get full weight
                distributed_weight_dict[key] = torch.empty(meta["shape"], dtype=meta["dtype"], device=device)

        dist.barrier()

        # Distribute weights
        for key in sorted(synced_meta_dict.keys()):
            meta = synced_meta_dict[key]
            is_tp = meta.get("is_tp", False)

            if is_tp:
                # TP weight: rank 0 sends different slices to each rank
                # Use send/recv to ensure each rank gets its own slice
                dist.barrier(group=self.tp_group)

                if is_weight_loader:
                    # Rank 0: send each rank's slice in order
                    for rank_idx in range(self.tp_size):
                        rank_key = f"{key}__tp_rank_{rank_idx}"
                        if rank_key in weight_dict:
                            if rank_idx == self.tp_rank:
                                # Copy to my own buffer
                                distributed_weight_dict[key].copy_(weight_dict[rank_key], non_blocking=True)
                            else:
                                # Send to other ranks
                                dist.send(weight_dict[rank_key].contiguous(), dst=rank_idx, group=self.tp_group)
                else:
                    # Other ranks: receive from rank 0
                    dist.recv(distributed_weight_dict[key], src=global_src_rank, group=self.tp_group)
            else:
                # Non-TP weight: broadcast to all ranks
                if is_weight_loader:
                    distributed_weight_dict[key].copy_(weight_dict[key], non_blocking=True)

                dist.broadcast(distributed_weight_dict[key], src=global_src_rank)

        torch_device_module.synchronize()

        logger.info(f"Weights distributed across {dist.get_world_size()} devices on {AI_DEVICE}")

        return distributed_weight_dict

    def _is_tp_weight(self, key):
        """Check if a weight key needs TP splitting.

        TP weights include:
        - Attention layers: to_q, to_k, to_v, to_out.0, q_norm, k_norm
        - FFN layers: net.0.proj, net.2
        """
        # Generic patterns that apply to all attention and FFN layers
        tp_patterns = [
            ".to_q.",
            ".to_k.",
            ".to_v.",
            ".to_out.0.",
            ".q_norm.",
            ".k_norm.",
            ".net.0.proj.",
            ".net.2.",
        ]
        return any(pattern in key for pattern in tp_patterns)

    def _get_split_type(self, key):
        """Determine the split type for a weight key.

        Returns:
            "col": Column split (to_q, to_k, to_v, net.0.proj)
            "row": Row split (to_out.0, net.2)
            "norm": Norm split (q_norm, k_norm)
            None: No split needed
        """
        if ".q_norm." in key or ".k_norm." in key:
            return "norm"
        elif ".to_q." in key or ".to_k." in key or ".to_v." in key or ".net.0.proj." in key:
            return "col"
        elif ".to_out.0." in key or ".net.2." in key:
            return "row"
        return None

    def _split_weight_for_tp(self, key, weight, tp_size):
        """
        Split a weight tensor for tensor parallel.
        Returns a list of split weights, one for each rank.
        """
        split_type = self._get_split_type(key)
        if split_type is None:
            # Unknown pattern, don't split
            return [weight] * tp_size

        if split_type == "norm":
            # 1D weights (norm weights): [hidden_dim] -> [hidden_dim/tp_size] per rank
            assert weight.dim() == 1, f"Norm weight should be 1D, got {weight.dim()}D for {key}"
            assert weight.shape[0] % tp_size == 0, f"hidden_dim ({weight.shape[0]}) must be divisible by tp_size ({tp_size}) for {key}"
            chunk_size = weight.shape[0] // tp_size
            return [weight[rank_idx * chunk_size : (rank_idx + 1) * chunk_size] for rank_idx in range(tp_size)]

        # 2D weights (linear layer weights)
        assert weight.dim() == 2, f"Linear weight should be 2D, got {weight.dim()}D for {key}"

        # Transpose to [in_dim, out_dim] format for easier splitting
        weight_t = weight.t()  # [in_dim, out_dim]

        if split_type == "col":
            # Column split: [out_dim, in_dim] -> [out_dim/tp_size, in_dim] per rank
            # Split along out_dim dimension
            assert weight_t.shape[1] % tp_size == 0, f"out_dim ({weight_t.shape[1]}) must be divisible by tp_size ({tp_size}) for {key}"
            chunk_size = weight_t.shape[1] // tp_size
            split_weights = []
            for rank_idx in range(tp_size):
                split_weight = weight_t[:, rank_idx * chunk_size : (rank_idx + 1) * chunk_size].t()  # Back to [out_dim/tp_size, in_dim]
                split_weights.append(split_weight)
        else:  # split_type == "row"
            # Row split: [out_dim, in_dim] -> [out_dim, in_dim/tp_size] per rank
            # Split along in_dim dimension
            assert weight_t.shape[0] % tp_size == 0, f"in_dim ({weight_t.shape[0]}) must be divisible by tp_size ({tp_size}) for {key}"
            chunk_size = weight_t.shape[0] // tp_size
            split_weights = []
            for rank_idx in range(tp_size):
                split_weight = weight_t[rank_idx * chunk_size : (rank_idx + 1) * chunk_size, :].t()  # Back to [out_dim, in_dim/tp_size]
                split_weights.append(split_weight)

        return split_weights

    def _init_infer(self):
        self.pre_infer = self.pre_infer_class(self.config)
        self.post_infer = self.post_infer_class(self.config)
        self.transformer_infer = self.transformer_infer_class(self.config)
        if hasattr(self.transformer_infer, "offload_manager"):
            self._init_offload_manager()

    @torch.no_grad()
    def _infer_cond_uncond(self, inputs, infer_condition=True, mm_perturb=None):
        self.transformer_infer.reset_guidance_perturbation()
        if mm_perturb:
            self.transformer_infer.set_guidance_perturbation(**mm_perturb)
        try:
            self.scheduler.infer_condition = infer_condition
            pre_infer_out = self.pre_infer.infer(self.pre_weight, inputs)

            # Apply sequence parallel pre-processing (only for video)
            if self.config.get("seq_parallel", False):
                pre_infer_out = self._seq_parallel_pre_process(pre_infer_out)

            # Apply tensor parallel pre-processing (split positional embeddings)
            if self.config.get("tensor_parallel", False):
                pre_infer_out = self._tensor_parallel_pre_process(pre_infer_out)

            vx, ax, video_embedded_timestep, audio_embedded_timestep = self.transformer_infer.infer(self.transformer_weights, pre_infer_out)

            # Apply sequence parallel post-processing (only for video)
            if self.config.get("seq_parallel", False):
                vx = self._seq_parallel_post_process(vx, self.original_video_seq_len)
                video_embedded_timestep = self._seq_parallel_post_process(video_embedded_timestep, self.original_video_seq_len)
                # Audio remains global, no gather needed

            vx, ax = self.post_infer.infer(self.post_weight, vx, ax, video_embedded_timestep, audio_embedded_timestep)
            return vx, ax
        finally:
            self.transformer_infer.reset_guidance_perturbation()

    @torch.no_grad()
    def _infer_mm_guider_cfg(self, inputs):
        """
        与 ltx ``multi_modal_guider_denoising_func`` + ``MultiModalGuider.calculate`` 对齐：
        cond / uncond / perturbed(STG) / isolated-modality 多路前向，经 transformer_infer 扰动标志实现。
        """
        sch = self.scheduler
        step_i = sch.step_index
        v_p, a_p = sch.mm_guider_video, sch.mm_guider_audio
        is_rerun = bool(getattr(sch, "is_rerun", False))
        v_skip = False if is_rerun else _mm_guider_should_skip_step(v_p["skip_step"], step_i)
        a_skip = False if is_rerun else _mm_guider_should_skip_step(a_p["skip_step"], step_i)

        need_neg = sch.needs_negative_prompt
        need_ptb = (not math.isclose(v_p["stg_scale"], 0.0)) or (not math.isclose(a_p["stg_scale"], 0.0))
        need_mod = (not math.isclose(v_p["modality_scale"], 1.0)) or (not math.isclose(a_p["modality_scale"], 1.0))

        if v_skip and a_skip and sch.mm_last_v_pred is not None and sch.mm_last_a_pred is not None:
            sch.v_noise_pred = sch.mm_last_v_pred
            sch.a_noise_pred = sch.mm_last_a_pred
            return

        v_noise_pred_cond, a_noise_pred_cond = self._infer_cond_uncond(inputs, infer_condition=True)

        if need_neg:
            v_noise_pred_uncond, a_noise_pred_uncond = self._infer_cond_uncond(inputs, infer_condition=False)
        else:
            v_noise_pred_uncond, a_noise_pred_uncond = None, None

        if need_ptb:
            v_sb = frozenset(v_p["stg_blocks"]) if not math.isclose(v_p["stg_scale"], 0.0) else frozenset()
            a_sb = frozenset(a_p["stg_blocks"]) if not math.isclose(a_p["stg_scale"], 0.0) else frozenset()
            v_noise_pred_ptb, a_noise_pred_ptb = self._infer_cond_uncond(
                inputs,
                infer_condition=True,
                mm_perturb={
                    "skip_video_self_blocks": v_sb,
                    "skip_audio_self_blocks": a_sb,
                    "skip_a2v": False,
                    "skip_v2a": False,
                },
            )
        else:
            v_noise_pred_ptb, a_noise_pred_ptb = None, None

        if need_mod:
            v_noise_pred_mod, a_noise_pred_mod = self._infer_cond_uncond(
                inputs,
                infer_condition=True,
                mm_perturb={
                    "skip_video_self_blocks": frozenset(),
                    "skip_audio_self_blocks": frozenset(),
                    "skip_a2v": True,
                    "skip_v2a": True,
                },
            )
        else:
            v_noise_pred_mod, a_noise_pred_mod = None, None

        v_out = (
            sch.mm_last_v_pred
            if v_skip and sch.mm_last_v_pred is not None
            else _multimodal_guider_calculate(
                v_noise_pred_cond,
                v_noise_pred_uncond,
                v_noise_pred_ptb,
                v_noise_pred_mod,
                cfg_scale=v_p["cfg_scale"],
                stg_scale=v_p["stg_scale"],
                modality_scale=v_p["modality_scale"],
                rescale_scale=v_p["rescale_scale"],
            )
        )
        a_out = (
            sch.mm_last_a_pred
            if a_skip and sch.mm_last_a_pred is not None
            else _multimodal_guider_calculate(
                a_noise_pred_cond,
                a_noise_pred_uncond,
                a_noise_pred_ptb,
                a_noise_pred_mod,
                cfg_scale=a_p["cfg_scale"],
                stg_scale=a_p["stg_scale"],
                modality_scale=a_p["modality_scale"],
                rescale_scale=a_p["rescale_scale"],
            )
        )

        sch.mm_last_v_pred = v_out
        sch.mm_last_a_pred = a_out
        sch.v_noise_pred = v_out
        sch.a_noise_pred = a_out

    @torch.no_grad()
    def _seq_parallel_pre_process(self, pre_infer_out):
        """
        Pre-process for sequence parallel: only split video sequences across ranks.
        Audio remains global (not split) as it has fewer tokens.
        """
        world_size = dist.get_world_size(self.seq_p_group)
        cur_rank = dist.get_rank(self.seq_p_group)

        # Only process video args for sequence parallel
        if pre_infer_out.video_args is not None:
            # Split x (latent)
            vx = pre_infer_out.video_args.x
            self.original_video_seq_len = vx.shape[0]  # Record original length before padding
            padding_size = (world_size - (vx.shape[0] % world_size)) % world_size
            if padding_size > 0:
                vx = F.pad(vx, (0, 0, 0, padding_size))
            pre_infer_out.video_args.x = torch.chunk(vx, world_size, dim=0)[cur_rank]

            # Split positional embeddings (cos_freqs, sin_freqs) for video self-attention
            if pre_infer_out.video_args.positional_embeddings is not None:
                v_cos, v_sin = pre_infer_out.video_args.positional_embeddings
                # For 4D tensors: [batch, num_heads, seq_len, head_dim], seq_len is at dim=2
                if v_cos.dim() == 4:
                    seq_dim = 2
                elif v_cos.dim() == 2:
                    seq_dim = 0
                else:
                    seq_dim = 1

                seq_len = v_cos.shape[seq_dim]
                padding_size = (world_size - (seq_len % world_size)) % world_size
                if padding_size > 0:
                    pad_spec = [0, 0] * (v_cos.dim() - seq_dim - 1) + [0, padding_size] + [0, 0] * seq_dim
                    v_cos = F.pad(v_cos, pad_spec)
                    v_sin = F.pad(v_sin, pad_spec)

                pre_infer_out.video_args.positional_embeddings = (torch.chunk(v_cos, world_size, dim=seq_dim)[cur_rank], torch.chunk(v_sin, world_size, dim=seq_dim)[cur_rank])

            # Split cross-attention positional embeddings for cross-modal attention
            if pre_infer_out.video_args.cross_positional_embeddings is not None:
                v_cross_cos, v_cross_sin = pre_infer_out.video_args.cross_positional_embeddings
                if v_cross_cos.dim() == 4:
                    seq_dim = 2
                elif v_cross_cos.dim() == 2:
                    seq_dim = 0
                else:
                    seq_dim = 1

                seq_len = v_cross_cos.shape[seq_dim]
                padding_size = (world_size - (seq_len % world_size)) % world_size
                if padding_size > 0:
                    pad_spec = [0, 0] * (v_cross_cos.dim() - seq_dim - 1) + [0, padding_size] + [0, 0] * seq_dim
                    v_cross_cos = F.pad(v_cross_cos, pad_spec)
                    v_cross_sin = F.pad(v_cross_sin, pad_spec)

                pre_infer_out.video_args.cross_positional_embeddings = (torch.chunk(v_cross_cos, world_size, dim=seq_dim)[cur_rank], torch.chunk(v_cross_sin, world_size, dim=seq_dim)[cur_rank])

            # Split timestep embeddings (sequence-length dependent)
            if pre_infer_out.video_args.timesteps is not None:
                v_timesteps = pre_infer_out.video_args.timesteps
                padding_size = (world_size - (v_timesteps.shape[0] % world_size)) % world_size
                if padding_size > 0:
                    v_timesteps = F.pad(v_timesteps, (0, 0, 0, padding_size))
                pre_infer_out.video_args.timesteps = torch.chunk(v_timesteps, world_size, dim=0)[cur_rank]

            if pre_infer_out.video_args.embedded_timestep is not None:
                v_embedded_timestep = pre_infer_out.video_args.embedded_timestep
                padding_size = (world_size - (v_embedded_timestep.shape[0] % world_size)) % world_size
                if padding_size > 0:
                    v_embedded_timestep = F.pad(v_embedded_timestep, (0, 0, 0, padding_size))
                pre_infer_out.video_args.embedded_timestep = torch.chunk(v_embedded_timestep, world_size, dim=0)[cur_rank]

            if pre_infer_out.video_args.cross_scale_shift_timestep is not None:
                v_cross_ss = pre_infer_out.video_args.cross_scale_shift_timestep
                padding_size = (world_size - (v_cross_ss.shape[0] % world_size)) % world_size
                if padding_size > 0:
                    v_cross_ss = F.pad(v_cross_ss, (0, 0, 0, padding_size))
                pre_infer_out.video_args.cross_scale_shift_timestep = torch.chunk(v_cross_ss, world_size, dim=0)[cur_rank]

            # cross_gate_timestep is a global [1, hidden_dim] gate derived from
            # the scheduler sigma, not a per-token tensor. Every sequence-
            # parallel rank must retain the same gate and broadcast it over its
            # local video tokens in the transformer block.

        # Audio remains global - no splitting needed
        # Audio has fewer tokens, so we keep it on all ranks

        return pre_infer_out

    @torch.no_grad()
    def _tensor_parallel_pre_process(self, pre_infer_out):
        """
        Pre-process for tensor parallel: split positional embeddings along head dimension.

        In tensor parallel, QKV projections are split along hidden_dim (which equals num_heads * head_dim),
        so positional embeddings need to be split along the head dimension to match.
        """
        if not self.config.get("tensor_parallel", False):
            return pre_infer_out

        tp_group = self.config.get("device_mesh").get_group(mesh_dim="tensor_p")
        tp_rank = dist.get_rank(tp_group)
        tp_size = dist.get_world_size(tp_group)

        # Get num_heads and head_dim from config
        v_num_heads = self.config.get("num_attention_heads", 32)
        v_head_dim = self.config.get("attention_head_dim", 128)
        a_num_heads = self.config.get("audio_num_attention_heads", 32)
        a_head_dim = self.config.get("audio_attention_head_dim", 64)

        v_num_heads_per_rank = v_num_heads // tp_size
        a_num_heads_per_rank = a_num_heads // tp_size

        def split_pe(pe, num_heads, num_heads_per_rank, tp_rank, tp_size):
            """Split positional embeddings along head dimension."""
            if pe is None:
                return None

            if isinstance(pe, tuple):
                cos_freqs, sin_freqs = pe

                if cos_freqs.dim() == 2 and cos_freqs.shape[0] == num_heads:
                    # Shape: [num_heads, head_dim] - split along num_heads dimension
                    cos_freqs_split = cos_freqs[tp_rank * num_heads_per_rank : (tp_rank + 1) * num_heads_per_rank, :]
                    sin_freqs_split = sin_freqs[tp_rank * num_heads_per_rank : (tp_rank + 1) * num_heads_per_rank, :]
                    return (cos_freqs_split, sin_freqs_split)
                elif cos_freqs.dim() == 4:
                    # Shape: [B, H, T, D] where H=num_heads, D=head_dim//2 (for SPLIT rope type)
                    # In apply_split_rotary_emb, if input is 2D [seq_len, num_heads_per_rank * head_dim]
                    # and PE is 4D [B, H, T, D], it will reshape input to [B, T, H, head_dim] then swapaxes to [B, H, T, head_dim]
                    # So H in PE should match num_heads_per_rank in the input
                    # Therefore, we need to split along H dimension: [B, H, T, D] -> [B, H/tp_size, T, D]
                    assert cos_freqs.shape[1] == num_heads, f"PE head dimension mismatch: cos_freqs.shape[1]={cos_freqs.shape[1]}, num_heads={num_heads}"
                    cos_freqs_split = cos_freqs[:, tp_rank * num_heads_per_rank : (tp_rank + 1) * num_heads_per_rank, :, :]
                    sin_freqs_split = sin_freqs[:, tp_rank * num_heads_per_rank : (tp_rank + 1) * num_heads_per_rank, :, :]
                    return (cos_freqs_split, sin_freqs_split)
                else:
                    # For other shapes, split along last dimension (hidden_dim)
                    head_dim = cos_freqs.shape[-1] // num_heads if cos_freqs.dim() > 1 and cos_freqs.shape[-1] % num_heads == 0 else cos_freqs.shape[-1]
                    hidden_dim_per_rank = num_heads_per_rank * head_dim
                    start_idx = tp_rank * hidden_dim_per_rank
                    end_idx = start_idx + hidden_dim_per_rank
                    cos_freqs_split = cos_freqs[..., start_idx:end_idx]
                    sin_freqs_split = sin_freqs[..., start_idx:end_idx]
                    return (cos_freqs_split, sin_freqs_split)
            else:
                # pe is a single tensor, split along last dimension
                head_dim = pe.shape[-1] // num_heads if pe.dim() > 1 and pe.shape[-1] % num_heads == 0 else pe.shape[-1]
                hidden_dim_per_rank = num_heads_per_rank * head_dim
                start_idx = tp_rank * hidden_dim_per_rank
                end_idx = start_idx + hidden_dim_per_rank
                return pe[..., start_idx:end_idx]

        # Process video args
        if pre_infer_out.video_args is not None:
            # Split positional embeddings for video self-attention
            if pre_infer_out.video_args.positional_embeddings is not None:
                pre_infer_out.video_args.positional_embeddings = split_pe(pre_infer_out.video_args.positional_embeddings, v_num_heads, v_num_heads_per_rank, tp_rank, tp_size)

            # Split cross-attention positional embeddings
            if pre_infer_out.video_args.cross_positional_embeddings is not None:
                pre_infer_out.video_args.cross_positional_embeddings = split_pe(pre_infer_out.video_args.cross_positional_embeddings, v_num_heads, v_num_heads_per_rank, tp_rank, tp_size)

        # Process audio args
        if pre_infer_out.audio_args is not None:
            # Split positional embeddings for audio self-attention
            if pre_infer_out.audio_args.positional_embeddings is not None:
                pre_infer_out.audio_args.positional_embeddings = split_pe(pre_infer_out.audio_args.positional_embeddings, a_num_heads, a_num_heads_per_rank, tp_rank, tp_size)

            # Split cross-attention positional embeddings
            if pre_infer_out.audio_args.cross_positional_embeddings is not None:
                pre_infer_out.audio_args.cross_positional_embeddings = split_pe(pre_infer_out.audio_args.cross_positional_embeddings, a_num_heads, a_num_heads_per_rank, tp_rank, tp_size)

        return pre_infer_out

    @torch.no_grad()
    def _seq_parallel_post_process(self, x, original_length=None):
        """
        Post-process for sequence parallel: gather results from all ranks and remove padding.

        Args:
            x: Tensor to gather
            original_length: Original sequence length before padding. If provided, truncate to this length.
        """
        world_size = dist.get_world_size(self.seq_p_group)
        gathered_x = [torch.empty_like(x) for _ in range(world_size)]
        dist.all_gather(gathered_x, x, group=self.seq_p_group)
        combined_output = torch.cat(gathered_x, dim=0)

        # Remove padding to restore original length
        if original_length is not None and combined_output.shape[0] > original_length:
            combined_output = combined_output[:original_length]

        return combined_output

    @torch.no_grad()
    def infer(self, inputs):
        if self.cpu_offload:
            if self.offload_granularity == "model" and self.scheduler.step_index == 0 and "wan2.2_moe" not in self.config["model_cls"]:
                self.to_cuda()
            elif self.offload_granularity != "model":
                self.pre_weight.to_cuda()
                self.post_weight.to_cuda()

        if self.config["enable_cfg"]:
            if getattr(self.scheduler, "mm_guider_enabled", False):
                if self.config["cfg_parallel"]:
                    raise NotImplementedError("LTX2 mm_guider 与 cfg_parallel 同时使用尚未实现，请关闭其一。")
                self._infer_mm_guider_cfg(inputs)
            else:
                assert self.scheduler.sample_guide_scale is not None and self.scheduler.sample_guide_scale > 1.0, f"CFG requires sample_guide_scale > 1, got {self.scheduler.sample_guide_scale!r}"
                if self.config["cfg_parallel"]:
                    # ==================== CFG Parallel Processing ====================
                    cfg_p_group = self.config["device_mesh"].get_group(mesh_dim="cfg_p")
                    assert dist.get_world_size(cfg_p_group) == 2, "cfg_p_world_size must be equal to 2"
                    cfg_p_rank = dist.get_rank(cfg_p_group)
                    if cfg_p_rank == 0:
                        v_noise_pred, a_noise_pred = self._infer_cond_uncond(inputs, infer_condition=True)
                    else:
                        v_noise_pred, a_noise_pred = self._infer_cond_uncond(inputs, infer_condition=False)

                    v_noise_pred_list = [torch.zeros_like(v_noise_pred) for _ in range(2)]
                    a_noise_pred_list = [torch.zeros_like(a_noise_pred) for _ in range(2)]
                    dist.all_gather(v_noise_pred_list, v_noise_pred, group=cfg_p_group)
                    dist.all_gather(a_noise_pred_list, a_noise_pred, group=cfg_p_group)
                    v_noise_pred_cond = v_noise_pred_list[0]  # cfg_p_rank == 0
                    v_noise_pred_uncond = v_noise_pred_list[1]  # cfg_p_rank == 1
                    a_noise_pred_cond = a_noise_pred_list[0]  # cfg_p_rank == 0
                    a_noise_pred_uncond = a_noise_pred_list[1]  # cfg_p_rank == 1
                else:
                    # ==================== CFG Processing ====================
                    v_noise_pred_cond, a_noise_pred_cond = self._infer_cond_uncond(inputs, infer_condition=True)
                    v_noise_pred_uncond, a_noise_pred_uncond = self._infer_cond_uncond(inputs, infer_condition=False)

                self.scheduler.v_noise_pred = v_noise_pred_uncond + self.scheduler.sample_guide_scale * (v_noise_pred_cond - v_noise_pred_uncond)
                self.scheduler.a_noise_pred = a_noise_pred_uncond + self.scheduler.sample_guide_scale * (a_noise_pred_cond - a_noise_pred_uncond)
        else:
            # ==================== No CFG ====================
            v_noise_pred, a_noise_pred = self._infer_cond_uncond(inputs, infer_condition=True)
            self.scheduler.v_noise_pred = v_noise_pred
            self.scheduler.a_noise_pred = a_noise_pred

        if self.cpu_offload:
            if self.offload_granularity == "model" and self.scheduler.step_index == self.scheduler.infer_steps - 1 and "wan2.2_moe" not in self.config["model_cls"]:
                self.to_cpu()
            elif self.offload_granularity != "model":
                self.pre_weight.to_cpu()
                self.post_weight.to_cpu()


class LTX2ARModel(LTX2Model):
    """LTX2.3 model variant for chunkwise autoregressive inference."""

    def _init_infer_class(self):
        if self.cpu_offload:
            raise NotImplementedError("ltx2_ar does not support cpu_offload yet.")
        if self.config.get("seq_parallel", False):
            raise NotImplementedError("ltx2_ar does not support sequence parallel; tensor parallel is supported.")
        self.pre_infer_class = LTX2PreInfer
        self.post_infer_class = LTX2PostInfer
        self.transformer_infer_class = LTX2ARTransformerInfer

    def _load_ckpt(self, unified_dtype, sensitive_layer):
        weight_dict = super()._load_ckpt(unified_dtype, sensitive_layer)
        normalized = {}
        for key, value in weight_dict.items():
            while key.startswith("module.") or key.startswith("_fsdp_wrapped_module."):
                key = key.split(".", 1)[1]
            if not key.startswith("model.diffusion_model."):
                key = f"model.diffusion_model.{key}"
            normalized[key] = value
        return normalized

    def configure_ar_cache(self, **kwargs):
        self.transformer_infer.configure_ar_cache(**kwargs)

    def set_ar_chunk(self, *, video_start: int, audio_start: int):
        self.transformer_infer.set_ar_chunk(video_start=video_start, audio_start=audio_start)

    @torch.no_grad()
    def _infer_cond_uncond(self, inputs, infer_condition=True, mm_perturb=None):
        if not infer_condition:
            branch = "negative"
        elif not mm_perturb:
            branch = "positive"
        elif mm_perturb.get("skip_a2v", False) or mm_perturb.get("skip_v2a", False):
            branch = "modality"
        else:
            branch = "perturbed"
        self.transformer_infer.set_ar_branch(branch)
        return super()._infer_cond_uncond(inputs, infer_condition=infer_condition, mm_perturb=mm_perturb)
